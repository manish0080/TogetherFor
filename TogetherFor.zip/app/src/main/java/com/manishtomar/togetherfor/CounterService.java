package com.manishtomar.togetherfor;

import android.app.*;
import android.content.*;
import android.os.*;
import java.util.*;

public class CounterService extends Service {
    private Handler handler;
    private Runnable tick;
    private static final String CHANNEL="together_counter";
    @Override public void onCreate() {
        super.onCreate();
        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Together for counter",NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Relationship duration counter"); getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        handler=new Handler(Looper.getMainLooper());
    }
    @Override public int onStartCommand(Intent intent,int flags,int id) {
        startForeground(7,buildNotification());
        if(tick!=null) handler.removeCallbacks(tick);
        tick=new Runnable(){ public void run(){ try { ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(7,buildNotification()); CounterWidgets.updateAll(CounterService.this); } catch(Exception ignored){} handler.postDelayed(this,1000); } };
        handler.post(tick);
        return START_STICKY;
    }
    private Notification buildNotification() {
        String value=CounterWidgets.value(this,2).replace("\n"," · ");
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_menu_recent_history).setContentTitle("together for 🤍").setContentText(value).setOngoing(true).setOnlyAlertOnce(true).build();
    }
    @Override public void onDestroy(){ if(handler!=null&&tick!=null) handler.removeCallbacks(tick); super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
