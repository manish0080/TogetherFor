package com.manishtomar.togetherfor;
import android.appwidget.*; import android.content.*;
public class CounterWidget7 extends AppWidgetProvider { @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){CounterWidgets.update(c,m,ids,7);} }
