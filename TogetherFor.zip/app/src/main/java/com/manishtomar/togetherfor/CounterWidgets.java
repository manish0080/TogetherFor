package com.manishtomar.togetherfor;

import android.appwidget.*;
import android.content.*;
import android.widget.RemoteViews;
import org.json.*;
import java.util.*;

class CounterWidgets {
    static long activeStart(Context c) {
        android.content.SharedPreferences p=c.getSharedPreferences("together",0);
        String id=p.getString("activeId","");
        try {
            JSONArray a=new JSONArray(p.getString("events","[]"));
            for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&id.equals(o.optString("id")))return o.optLong("start",0);}
            if(a.length()>0)return a.optJSONObject(0).optLong("start",0);
        } catch(Exception ignored){}
        return p.getLong("start",0);
    }
    static String value(Context c, int mode) {
        long start=activeStart(c); if(start<=0)return "Open app to add a date";
        long sec=Math.max(0,(System.currentTimeMillis()-start)/1000), mins=sec/60, hrs=mins/60, days=hrs/24;
        Calendar a=Calendar.getInstance(),b=Calendar.getInstance();a.setTimeInMillis(start);b.setTimeInMillis(System.currentTimeMillis());
        int y=b.get(Calendar.YEAR)-a.get(Calendar.YEAR),m=b.get(Calendar.MONTH)-a.get(Calendar.MONTH),d=b.get(Calendar.DAY_OF_MONTH)-a.get(Calendar.DAY_OF_MONTH);
        if(d<0){m--;Calendar p=(Calendar)b.clone();p.add(Calendar.MONTH,-1);d+=p.getActualMaximum(Calendar.DAY_OF_MONTH);}if(m<0){y--;m+=12;}
        switch(mode){
            case 1:return y+"y, "+m+"m, "+d+"d";
            case 2:return days+" days\\n"+(hrs%24)+" hr  "+(mins%60)+" min  "+(sec%60)+" sec";
            case 3:return hrs+" total hours";
            case 4:return mins+" total minutes";
            case 5:return sec+" total seconds";
            case 6:return days+" days · "+String.format(Locale.US,"%02d:%02d:%02d",hrs%24,mins%60,sec%60);
            default:return String.format(Locale.US,"%02d:%02d:%02d",hrs%24,mins%60,sec%60);
        }
    }
    static void update(Context c,AppWidgetManager mgr,int[] ids,int mode){
        for(int id:ids){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_counter);
            v.setTextViewText(R.id.widget_title,"together for 🤍");v.setTextViewText(R.id.widget_value,value(c,mode));mgr.updateAppWidget(id,v);}
    }
    static void updateAll(Context c){
        AppWidgetManager m=AppWidgetManager.getInstance(c);
        updateProvider(c,m,CounterWidget1.class,1);updateProvider(c,m,CounterWidget2.class,2);
        updateProvider(c,m,CounterWidget3.class,3);updateProvider(c,m,CounterWidget4.class,4);
        updateProvider(c,m,CounterWidget5.class,5);updateProvider(c,m,CounterWidget6.class,6);
        updateProvider(c,m,CounterWidget7.class,7);
    }
    static void updateProvider(Context c,AppWidgetManager m,Class<?> cls,int mode){
        int[] ids=m.getAppWidgetIds(new ComponentName(c,cls));update(c,m,ids,mode);
    }
}
