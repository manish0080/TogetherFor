package com.manishtomar.togetherfor;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.*;
import java.util.*;
import java.text.*;

public class MainActivity extends Activity {
    LinearLayout root, list;
    TextView liveClock;
    HandlerClock clock;
    JSONArray events;
    String activeId = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Locale.setDefault(new Locale("en", "IN"));
        getWindow().setStatusBarColor(Color.rgb(20,24,34));
        getWindow().setNavigationBarColor(Color.BLACK);
        loadEvents();
        buildUI();
        renderEvents();
        clock = new HandlerClock();
        clock.start();
    }

    void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20,24,20,24); root.setBackgroundColor(Color.rgb(246,247,251));
        scroll.addView(root);

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView title = new TextView(this); title.setText("Together for 🤍");
        title.setTextSize(27); title.setTextColor(Color.rgb(37,48,73)); title.setTypeface(null,1);
        top.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        Button add = new Button(this); add.setText("+ Add");
        add.setOnClickListener(v -> showEditor(null)); top.addView(add);
        root.addView(top);

        liveClock = new TextView(this); liveClock.setTextSize(15);
        liveClock.setTextColor(Color.rgb(92,101,120)); liveClock.setPadding(0,8,0,18);
        root.addView(liveClock);

        TextView heading = new TextView(this); heading.setText("Your counters");
        heading.setTextSize(20); heading.setTextColor(Color.rgb(37,48,73)); heading.setTypeface(null,1);
        root.addView(heading);
        TextView hint = new TextView(this);
        hint.setText("Tap a counter to make it the widget counter. Use Edit to change its name or start date.");
        hint.setTextSize(13); hint.setTextColor(Color.rgb(95,101,115)); hint.setPadding(0,5,0,12); root.addView(hint);

        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list);
        TextView footer = new TextView(this);
        footer.setText("Indian English · en-IN\\nPast dates and times are supported. Future start dates are not allowed.");
        footer.setTextSize(12); footer.setTextColor(Color.rgb(105,110,125)); footer.setPadding(2,20,2,8); root.addView(footer);

        Button notif = new Button(this); notif.setText("ENABLE LIVE LOCK-SCREEN COUNTER");
        notif.setOnClickListener(v -> {
            if(android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},42);
            }
            try { startForegroundService(new Intent(this,CounterService.class)); }
            catch(Exception e) { Toast.makeText(this,"Allow notifications and try again",Toast.LENGTH_LONG).show(); }
        }); root.addView(notif);
        setContentView(scroll);
    }

    void loadEvents() {
        String raw=getSharedPreferences("together",0).getString("events","[]");
        try { events=new JSONArray(raw); } catch(Exception e) { events=new JSONArray(); }
        activeId=getSharedPreferences("together",0).getString("activeId","");
        if(events.length()==0) {
            // Keep an empty first-run state. User can add any number of counters.
        }
    }
    void saveEvents() {
        getSharedPreferences("together",0).edit().putString("events",events.toString()).putString("activeId",activeId).apply();
        CounterWidgets.updateAll(this);
    }
    JSONObject findById(String id) {
        for(int i=0;i<events.length();i++) { JSONObject o=events.optJSONObject(i); if(o!=null && id.equals(o.optString("id"))) return o; }
        return null;
    }
    long activeStart() {
        JSONObject o=findById(activeId);
        if(o==null && events.length()>0) { o=events.optJSONObject(0); if(o!=null) activeId=o.optString("id"); }
        return o==null ? 0 : o.optLong("start",0);
    }
    void renderEvents() {
        if(list==null) return;
        list.removeAllViews();
        if(events.length()==0) {
            TextView empty=new TextView(this); empty.setText("No counters yet 🤍\\nTap + Add to create your first counter.");
            empty.setTextSize(16); empty.setTextColor(Color.rgb(65,73,92)); empty.setGravity(Gravity.CENTER);
            empty.setPadding(18,35,18,35); list.addView(empty); return;
        }
        for(int i=0;i<events.length();i++) {
            JSONObject o=events.optJSONObject(i); if(o==null) continue;
            final String id=o.optString("id");
            boolean selected=id.equals(activeId);
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(16,14,16,12); card.setBackgroundColor(selected?Color.rgb(226,234,248):Color.WHITE);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,0,0,12); list.addView(card,cp);
            TextView name=new TextView(this); name.setText((selected?"✓ ":"")+"together for 🤍  ·  "+o.optString("name","Our date"));
            name.setTextSize(16); name.setTypeface(null,1); name.setTextColor(Color.rgb(39,51,77)); card.addView(name);
            TextView value=new TextView(this); value.setTextSize(18); value.setTextColor(Color.rgb(49,61,86));
            value.setPadding(0,8,0,8); card.addView(value);
            value.setText(formatCounter(o.optLong("start",0),1));
            TextView date=new TextView(this); date.setTextSize(12); date.setTextColor(Color.rgb(105,110,125));
            date.setText(new SimpleDateFormat("dd MMM yyyy, hh:mm a",new Locale("en","IN")).format(new Date(o.optLong("start",0))));
            card.addView(date);
            LinearLayout buttons=new LinearLayout(this); buttons.setGravity(Gravity.END);
            Button use=new Button(this); use.setText(selected?"Selected":"Use for widgets");
            use.setOnClickListener(v->{activeId=id;saveEvents();renderEvents();});
            Button edit=new Button(this); edit.setText("Edit");
            edit.setOnClickListener(v->showEditor(id));
            Button del=new Button(this); del.setText("Delete");
            del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Delete counter?").setMessage("This cannot be undone.")
                .setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->deleteEvent(id)).show());
            buttons.addView(use); buttons.addView(edit); buttons.addView(del); card.addView(buttons);
        }
    }
    void deleteEvent(String id) {
        JSONArray newer=new JSONArray();
        for(int i=0;i<events.length();i++){JSONObject o=events.optJSONObject(i);if(o!=null&&!id.equals(o.optString("id")))newer.put(o);}
        events=newer; if(id.equals(activeId)) activeId=events.length()>0?events.optJSONObject(0).optString("id"):"";
        saveEvents();renderEvents();
    }
    void showEditor(String editId) {
        JSONObject existing=editId==null?null:findById(editId);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(20,8,20,0);
        EditText name=new EditText(this);name.setSingleLine(true);name.setHint("Name (e.g. The day we met)");
        EditText date=new EditText(this);date.setSingleLine(true);date.setHint("Date: YYYY-MM-DD");
        EditText time=new EditText(this);time.setSingleLine(true);time.setHint("Time: HH:MM (24-hour)");
        if(existing!=null){
            name.setText(existing.optString("name","Our date"));
            Calendar c=Calendar.getInstance();c.setTimeInMillis(existing.optLong("start"));
            date.setText(String.format(Locale.US,"%04d-%02d-%02d",c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH)));
            time.setText(String.format(Locale.US,"%02d:%02d",c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE)));
        } else {
            Calendar c=Calendar.getInstance();
            date.setText(String.format(Locale.US,"%04d-%02d-%02d",c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH)));
            time.setText(String.format(Locale.US,"%02d:%02d",c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE)));
        }
        Button chooseDate=new Button(this);chooseDate.setText("Choose date");
        chooseDate.setOnClickListener(v->{Calendar c=Calendar.getInstance();try{String[] p=date.getText().toString().split("-");c.set(Integer.parseInt(p[0]),Integer.parseInt(p[1])-1,Integer.parseInt(p[2]));}catch(Exception ignored){}
            new DatePickerDialog(this,(dp,y,m,d)->date.setText(String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d)),c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();});
        Button chooseTime=new Button(this);chooseTime.setText("Choose time");
        chooseTime.setOnClickListener(v->{Calendar c=Calendar.getInstance();try{String[] p=time.getText().toString().split(":");c.set(Calendar.HOUR_OF_DAY,Integer.parseInt(p[0]));c.set(Calendar.MINUTE,Integer.parseInt(p[1]));}catch(Exception ignored){}
            new TimePickerDialog(this,(tp,h,m)->time.setText(String.format(Locale.US,"%02d:%02d",h,m)),c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show();});
        box.addView(name);box.addView(date);box.addView(chooseDate);box.addView(time);box.addView(chooseTime);
        new AlertDialog.Builder(this).setTitle(existing==null?"Add counter":"Edit counter").setView(box)
          .setNegativeButton("Cancel",null).setPositiveButton(existing==null?"Add":"Save",(dialog,which)->{
            try{
                String[] d=date.getText().toString().trim().split("-");String[] t=time.getText().toString().trim().split(":");
                Calendar c=Calendar.getInstance();c.setLenient(false);c.set(Integer.parseInt(d[0]),Integer.parseInt(d[1])-1,Integer.parseInt(d[2]),Integer.parseInt(t[0]),Integer.parseInt(t[1]),0);c.set(Calendar.MILLISECOND,0);
                long start=c.getTimeInMillis();if(start>System.currentTimeMillis()){Toast.makeText(this,"Choose a date and time in the past or present.",Toast.LENGTH_LONG).show();return;}
                String nm=name.getText().toString().trim();if(nm.isEmpty())nm="Our date";
                if(existing==null){JSONObject o=new JSONObject();o.put("id",UUID.randomUUID().toString());o.put("name",nm);o.put("start",start);events.put(o);activeId=o.getString("id");}
                else{existing.put("name",nm);existing.put("start",start);}
                saveEvents();renderEvents();
            }catch(Exception e){Toast.makeText(this,"Please enter a valid date and time.",Toast.LENGTH_LONG).show();}
          }).show();
    }
    static String formatCounter(long start,int mode) {
        if(start<=0)return "Add a date to begin";
        long sec=Math.max(0,(System.currentTimeMillis()-start)/1000), mins=sec/60, hrs=mins/60, days=hrs/24;
        Calendar a=Calendar.getInstance(),b=Calendar.getInstance();a.setTimeInMillis(start);b.setTimeInMillis(System.currentTimeMillis());
        int y=b.get(Calendar.YEAR)-a.get(Calendar.YEAR),m=b.get(Calendar.MONTH)-a.get(Calendar.MONTH),d=b.get(Calendar.DAY_OF_MONTH)-a.get(Calendar.DAY_OF_MONTH);
        if(d<0){m--;Calendar p=(Calendar)b.clone();p.add(Calendar.MONTH,-1);d+=p.getActualMaximum(Calendar.DAY_OF_MONTH);}if(m<0){y--;m+=12;}
        switch(mode){
            case 1:return y+"y, "+m+"m, "+d+"d";
            case 2:return days+" days · "+(hrs%24)+" hr · "+(mins%60)+" min · "+(sec%60)+" sec";
            case 3:return hrs+" total hours";
            case 4:return mins+" total minutes";
            case 5:return sec+" total seconds";
            case 6:return days+" days · "+String.format(Locale.US,"%02d:%02d:%02d",hrs%24,mins%60,sec%60);
            default:return String.format(Locale.US,"%02d:%02d:%02d",hrs%24,mins%60,sec%60);
        }
    }
    class HandlerClock {
        android.os.Handler h=new android.os.Handler();
        Runnable r=new Runnable(){public void run(){
            liveClock.setText("Current time · "+new SimpleDateFormat("hh:mm:ss a",new Locale("en","IN")).format(new Date()));
            if(list!=null) {
                for(int i=0;i<list.getChildCount();i++){
                    View card=list.getChildAt(i);
                    if(card instanceof LinearLayout) {
                        LinearLayout ll=(LinearLayout)card;
                        for(int j=0;j<ll.getChildCount();j++) if(ll.getChildAt(j) instanceof TextView && j==1) {
                            // Each counter card has title at 0, value at 1, date at 2, buttons at 3.
                            int idx=events.length()-1-i;
                            JSONObject o=events.optJSONObject(i);
                            if(o!=null)((TextView)ll.getChildAt(j)).setText(formatCounter(o.optLong("start"),1));
                        }
                    }
                }
            }
            h.postDelayed(this,1000);
        }};
        void start(){h.post(r);}
    }
    @Override protected void onDestroy(){if(clock!=null)clock.h.removeCallbacks(clock.r);super.onDestroy();}
}
