# Together for 🤍 — Android starter project

A personal relationship-counter Android app starter, with an iPhone/Vivo-inspired clean UI and Indian English (`en-IN`) wording.

## Included in this starter
- Add multiple named counters (for example, “The day we met”)
- Edit and delete counters
- Choose a past or present date and time; future dates are rejected
- Select one counter as the active counter used by widgets
- Live in-app clock and counter display
- Seven home-screen widget styles: years/months/days, days plus clock, total hours, total minutes, total seconds, days + HH:MM:SS, and HH:MM:SS
- Ongoing notification attempt for lock-screen display
- GitHub Actions workflow to build a debug APK

## Important platform limitations
- Android home-screen widgets are throttled by the OS and cannot be guaranteed to redraw every second. The app UI updates every second while open.
- The lock-screen display is an ongoing notification, not a replacement for the system clock or an arbitrary lock-screen widget. Vivo/Funtouch OS notification and battery settings may affect visibility and background behavior.
- This starter has not been built or tested on a physical Vivo V40. Treat the generated APK as a test build.

## Build on GitHub
1. Create a repository named `TogetherFor`.
2. Upload all files in this ZIP to the repository root, including `.github/workflows/build-apk.yml`.
3. Open **Actions** → **Build TogetherFor APK** → **Run workflow**.
4. Open the completed run → **Artifacts** → download `TogetherFor-debug-apk`.
5. Extract the artifact ZIP and install `app-debug.apk`.

## Use
1. Open the app and tap **+ Add**.
2. Give the counter a name, choose a date and time, then tap Add.
3. Use **Edit** to change its name/date/time or **Delete** to remove it.
4. Tap **Use for widgets** on the counter you want the home-screen widgets to show.
5. Long-press home screen → Widgets → Together for 🤍 and choose a widget style.
6. Tap **Enable live lock-screen counter** and allow notifications. Enable lock-screen notifications in Vivo settings.

## Notes
The current starter keeps counter data on-device. It does not upload dates or relationship details to a server.
